﻿// Create Friend Class below this line


// Don't change this code
window.onload = function() {
	const faveList = [];

	// Start typing your code below this line





}
// Do not type anything below this line